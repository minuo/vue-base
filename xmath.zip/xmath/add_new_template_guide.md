# 添加新小学数学试题模板完整指南

基于我们的 ES6 模块化试题模板结构，本指南将详细说明如何为系统添加新的试题模板，包括支持同一个知识点的多种题目表述变种。

## 一、新增模板的基本步骤

### 1.1 确定模板分类
首先，需要确定新模板所属的年级和知识点分类：
- 年级：grade1 - grade6
- 知识点：addition（加法）、subtraction（减法）、multiplication（乘法）、division（除法）、geometry（几何）等

### 1.2 创建模板文件
在正确的目录下创建新的模板文件，文件命名规则为：`[功能描述].[模板类型].template.js`

例如：三年级乘法表模板应放在 `templates/math/grade3/multiplication-table/` 目录下

### 1.3 填充模板结构
按照标准化模板结构填充内容

## 二、支持多种题目表述变种的模板

为了提高题目多样性，系统支持在单个模板文件中定义同一个知识点的多种题目表述。这样可以避免重复的模板文件，同时为学生提供更丰富的练习体验。

### 2.1 完整示例（长方形面积计算 - 支持多种表述）

```javascript
// templates/math/grade5/geometry/area-calculation.rectangle.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE5-GEOMETRY-AREA-001",
  template_name: "长方形面积计算",
  description: "五年级几何题，计算长方形的面积，包含多种题目表述",
  grade: GRADE_LEVEL.GRADE5,
  // 使用 templates 数组支持多种题目表述
  templates: [
    '一个长方形的长是{{length}}厘米，宽是{{width}}厘米，它的面积是多少平方厘米？',
    '有一个长方形，长{{length}}厘米，宽{{width}}厘米，这个长方形的面积是多少？',
    '长方形的长为{{length}}cm，宽为{{width}}cm，求它的面积',
    '已知一个长方形的长是{{length}}厘米，宽是{{width}}厘米，计算其面积',
    '{{length}}厘米长、{{width}}厘米宽的长方形面积是多少平方厘米？'
  ],
  type: "calculation",
  knowledge_code: "math-grade5-geometry-area-rectangle",
  difficulty: DIFFICULTY_LEVEL.MEDIUM,
  variables: {
    length: { type: "integer", min: 1, max: 100 },
    width: { type: "integer", min: 1, max: 100 }
  },
  answer: (length, width) => {
    return length * width;
  }
};

if (!validateTemplate(template)) {
  throw new Error(`Template validation failed for ${template.template_id}`);
}

export default template;
```

### 2.2 关键说明
- 使用 `templates` 数组而不是单个 `template` 字段
- 数组中的每个元素都是一个独立的题目表述
- 所有表述共享相同的变量定义、答案计算逻辑和元数据

## 三、使用多种题目表述的工具函数

系统提供了工具函数来帮助处理多个模板：

```javascript
// 从模板数组中随机选择一个
import { selectRandomTemplate, renderTemplate } from './common/utils.js';

// 使用示例
const selectedTemplate = selectRandomTemplate(template.templates);
const question = renderTemplate(selectedTemplate, { length: 5, width: 3 });
```

## 四、完整模板示例（新增三年级乘法表模板）

让我们创建一个新的三年级乘法表模板作为示例：

```javascript
// templates/math/grade3/multiplication-table/times-table.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE3-MULTIPLICATION-TABLE-001",
  template_name: "乘法表练习",
  description: "三年级乘法表基础练习，帮助学生熟练掌握乘法口诀",
  grade: GRADE_LEVEL.GRADE3,
  templates: [
    '{{num1}} × {{num2}} = ?',
    '计算 {{num1}} 乘以 {{num2}} 等于多少？',
    '{{num1}} 乘 {{num2}} 的结果是？',
    '请算出 {{num1}} × {{num2}} 的值'
  ],
  type: "calculation",
  knowledge_code: "math-grade3-multiplication-table-basic",
  difficulty: DIFFICULTY_LEVEL.MEDIUM,
  variables: {
    num1: { type: "integer", min: 1, max: 9 },
    num2: { type: "integer", min: 1, max: 9 }
  },
  answer: (num1, num2) => {
    return num1 * num2;
  }
};

if (!validateTemplate(template)) {
  throw new Error(`Template validation failed for ${template.template_id}`);
}

export default template;
```

## 五、新增模板的完整流程

### 5.1 目录结构检查
确保新模板的目录存在，如果不存在需要创建：
```bash
mkdir -p templates/math/grade3/multiplication-table
```

### 5.2 创建模板文件
将上述示例代码保存为：`templates/math/grade3/multiplication-table/times-table.template.js`

### 5.3 运行验证
运行模板验证工具确保模板符合规范：
```bash
npx eslint templates/math/grade3/multiplication-table/ --config template-security-rules.json
```

### 5.4 编写单元测试
为新模板添加单元测试，确保功能正常：
```javascript
// tests/grade3-templates.test.js
import { describe, it, expect } from 'vitest';
import TimesTableTemplate from '../templates/math/grade3/multiplication-table/times-table.template.js';

describe('Grade 3 Multiplication Table Template', () => {
  it('should have correct grade and difficulty', () => {
    expect(TimesTableTemplate.grade).toBe('grade3');
    expect(TimesTableTemplate.difficulty).toBe('medium');
  });
  
  it('should support multiple templates', () => {
    expect(Array.isArray(TimesTableTemplate.templates)).toBe(true);
    expect(TimesTableTemplate.templates.length).toBeGreaterThan(0);
  });
  
  it('answer function should calculate correctly', () => {
    expect(TimesTableTemplate.answer(3, 5)).toBe(15);
    expect(TimesTableTemplate.answer(7, 8)).toBe(56);
  });
});
```

### 5.5 测试运行
运行所有相关测试，确保新模板正常工作：
```bash
npx vitest run tests/grade3-templates.test.js
```

## 六、不同类型模板的创建示例

### 6.1 五年级几何题模板
```javascript
// templates/math/grade5/geometry/area-calculation.rectangle.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE5-GEOMETRY-AREA-001",
  template_name: "长方形面积计算",
  description: "五年级几何题，计算长方形的面积，包含多种题目表述",
  grade: GRADE_LEVEL.GRADE5,
  templates: [
    '一个长方形的长是{{length}}厘米，宽是{{width}}厘米，它的面积是多少平方厘米？',
    '有一个长方形，长{{length}}厘米，宽{{width}}厘米，这个长方形的面积是多少？',
    '长方形的长为{{length}}cm，宽为{{width}}cm，求它的面积',
    '已知一个长方形的长是{{length}}厘米，宽是{{width}}厘米，计算其面积',
    '{{length}}厘米长、{{width}}厘米宽的长方形面积是多少平方厘米？'
  ],
  type: "calculation",
  knowledge_code: "math-grade5-geometry-area-rectangle",
  difficulty: DIFFICULTY_LEVEL.MEDIUM,
  variables: {
    length: { type: "integer", min: 1, max: 100 },
    width: { type: "integer", min: 1, max: 100 }
  },
  answer: (length, width) => {
    return length * width;
  }
};

export default template;
```

### 6.2 六年级应用题模板
```javascript
// templates/math/grade6/applied-problems/distance-speed-time.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE6-APPLIED-DISTANCE-001",
  template_name: "距离速度时间问题",
  description: "六年级行程问题，应用距离=速度×时间的公式",
  grade: GRADE_LEVEL.GRADE6,
  templates: [
    '一辆汽车以每小时{{speed}}公里的速度行驶，行驶了{{time}}小时，这辆汽车一共行驶了多少公里？',
    '汽车的速度是{{speed}}km/h，行驶时间为{{time}}小时，行驶的总距离是多少？',
    '已知速度为{{speed}}公里每小时，时间{{time}}小时，求行驶的距离',
    '{{speed}}km/h的速度行驶{{time}}小时，总共走了多少路？'
  ],
  type: "calculation",
  knowledge_code: "math-grade6-applied-distance-speed-time",
  difficulty: DIFFICULTY_LEVEL.HARD,
  variables: {
    speed: { type: "integer", min: 10, max: 120 },
    time: { type: "number", min: 0.5, max: 10 }
  },
  answer: (speed, time) => {
    return speed * time;
  }
};

export default template;
```

## 七、注意事项

1. **教学内容审核**：新模板必须符合小学各年级的教学大纲要求
2. **难度级别控制**：根据目标年级合理设置难度，避免过难或过易
3. **变量约束**：变量的取值范围应符合学生的认知水平
4. **安全规范**：禁止在模板中使用危险函数或收集敏感信息
5. **代码复用**：尽可能使用公共常量和工具函数
6. **多种表述**：对于常见知识点，建议提供3-5种不同的题目表述以增加练习多样性
7. **测试覆盖**：确保新模板有完善的单元测试

通过遵循以上步骤，您可以轻松地为系统添加新的小学数学试题模板，保持整个代码库的一致性和可维护性。

## 八、演示运行

为了展示多种模板表述的功能，请运行 demo 文件：
```bash
node demo_multiple_templates.js
```

这将演示如何从多个题目表述中随机选择并生成具体的数学题目。