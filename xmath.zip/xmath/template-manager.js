#!/usr/bin/env node

/**
 * 模板管理工具 - 用于自动化生成和维护数学试题模板
 * 避免每次手动修改代码文件
 */

import fs from 'fs';
import path from 'path';
import readline from 'readline';

// 创建命令行交互接口
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// 项目根目录
const ROOT_DIR = path.resolve(process.cwd());
const TEMPLATES_DIR = path.join(ROOT_DIR, 'templates', 'math');

// 通用模板结构
const templateTemplate = (data) => {
  const templatesArray = data.templates.map(t => `    '${t.replace(/'/g, "\\'")}'`).join(',\n');
  const variablesObject = Object.entries(data.variables || {}).map(([key, value]) => `    ${key}: { type: "${value.type}", min: ${value.min}, max: ${value.max} }`).join(',\n');
  
  return `// ${data.filePath}
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "${data.id}",
  template_name: "${data.name}",
  description: "${data.description}",
  grade: GRADE_LEVEL.${data.grade.toUpperCase()},
  templates: [
${templatesArray}
  ],
  type: "${data.type}",
  knowledge_code: "${data.knowledgeCode}",
  difficulty: DIFFICULTY_LEVEL.${data.difficulty.toUpperCase()},
  variables: {
${variablesObject}
  },
  answer: ${data.answer}
};

if (!validateTemplate(template)) {
  throw new Error('Template validation failed for ' + template.template_id);
}

export default template;
`;
};

// 创建模板的主要函数
const createTemplate = async () => {
  console.log('=== 创建新的数学模板 ===\n');

  // 收集用户输入
  const id = await askQuestion('请输入模板ID（如 MATH-GRADE3-ADDITION-001）: ');
  const name = await askQuestion('请输入模板名称: ');
  const description = await askQuestion('请输入模板描述: ');
  const grade = await askQuestion('请输入年级（grade1 - grade6）: ');
  const knowledgeCode = await askQuestion('请输入知识点代码（如 math-grade3-addition-basic）: ');
  const type = await askQuestion('请输入题目类型（calculation, multiple_choice）: ');
  const difficulty = await askQuestion('请输入难度级别（easy, medium, hard）: ');

  // 收集题目表述
  const templatesCount = parseInt(await askQuestion('请输入题目表述数量（3-5个）: '));
  const templates = [];
  for (let i = 0; i < templatesCount; i++) {
    const templateStr = await askQuestion(`请输入第 ${i + 1} 个题目表述: `);
    templates.push(templateStr);
  }

  // 收集变量
  const variablesCount = parseInt(await askQuestion('请输入变量数量: '));
  const variables = {};
  for (let i = 0; i < variablesCount; i++) {
    const varName = await askQuestion(`请输入第 ${i + 1} 个变量名: `);
    const varType = await askQuestion(`请输入 ${varName} 的类型（integer, number, string）: `);
    const varMin = await askQuestion(`请输入 ${varName} 的最小值: `);
    const varMax = await askQuestion(`请输入 ${varName} 的最大值: `);
    variables[varName] = { type: varType, min: varMin, max: varMax };
  }

  // 收集答案函数
  console.log('请输入答案函数代码（例如: (a, b) => a + b）:');
  const answerCode = await askQuestion('> ');

  // 构建文件路径
  const category = knowledgeCode.split('-')[3] || 'general';
  const fileName = `${category}.${type}.template.js`.replace(/[\\s_-]+/g, '-');
  const targetDir = path.join(TEMPLATES_DIR, grade, category);
  const filePath = path.join(targetDir, fileName);

  // 检查并创建目录
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
    console.log(`\n✓ 创建目录: ${targetDir}`);
  }

  // 构建模板数据
  const templateData = {
    id,
    name,
    description,
    grade,
    knowledgeCode,
    type,
    difficulty,
    templates,
    variables,
    answer: answerCode,
    filePath: path.relative(ROOT_DIR, filePath)
  };

  // 生成模板文件
  const content = templateTemplate(templateData);
  fs.writeFileSync(filePath, content);
  console.log(`\n✓ 创建模板文件: ${filePath}`);

  console.log('\n=== 模板创建完成 ===');
  console.log(`📁 位置: ${filePath}`);
  console.log(`✅ 请运行 'node demo_multiple_templates.js' 测试新模板`);

  rl.close();
};

// 批量更新模板的函数
const batchUpdateTemplates = () => {
  console.log('=== 批量更新模板 ===');
  console.log('功能: 更新现有模板以符合最新的系统标准');

  // 这里可以添加批量更新逻辑
  // 例如: 更新所有模板的结构、修复共同问题等
  
  console.log('批量更新功能正在开发中...');
  rl.close();
};

// 验证所有模板的函数
const validateAllTemplates = () => {
  console.log('=== 验证所有模板 ===');

  const scanAndValidate = (dir) => {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    
    for (const item of items) {
      const fullPath = path.join(dir, item.name);
      
      if (item.isDirectory()) {
        scanAndValidate(fullPath);
      } else if (item.isFile() && fullPath.endsWith('.template.js')) {
        try {
          // 使用动态导入验证模板
          import(fullPath).then(templateModule => {
            console.log(`✓ ${path.relative(ROOT_DIR, fullPath)} - 验证通过`);
          }).catch(error => {
            console.error(`✗ ${path.relative(ROOT_DIR, fullPath)} - 验证失败: ${error.message}`);
          });
        } catch (error) {
          console.error(`✗ ${path.relative(ROOT_DIR, fullPath)} - 加载错误`);
        }
      }
    }
  };

  scanAndValidate(TEMPLATES_DIR);
  rl.close();
};

// 显示帮助信息
const showHelp = () => {
  console.log('=== 模板管理工具 ===');
  console.log('使用方法: node template-manager.js [命令]');
  console.log('');
  console.log('可用命令:');
  console.log('  create    - 创建新的数学模板');
  console.log('  update    - 批量更新现有模板');
  console.log('  validate  - 验证所有模板的完整性');
  console.log('  help      - 显示此帮助信息');
  console.log('');
  console.log('示例:');
  console.log('  node template-manager.js create');
  console.log('  node template-manager.js validate');
  rl.close();
};

// 通用问题询问函数
const askQuestion = (question) => {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
};

// 处理命令行参数
const main = () => {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'create':
      createTemplate();
      break;
    case 'update':
      batchUpdateTemplates();
      break;
    case 'validate':
      validateAllTemplates();
      break;
    case 'help':
    case undefined:
      showHelp();
      break;
    default:
      console.error(`未知命令: ${command}`);
      showHelp();
      break;
  }
};

// 启动应用
main();