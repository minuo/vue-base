// templates/math/grade5/geometry/area-calculation.rectangle.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE5-GEOMETRY-AREA-001",
  template_name: "长方形面积计算",
  description: "五年级几何题，计算长方形的面积，包含多种题目表述",
  grade: GRADE_LEVEL.GRADE5,
  // 支持多种题目模板变种
  templates: [
    '一个长方形的长是{{length}}厘米，宽是{{width}}厘米，它的面积是多少平方厘米？',
    '有一个长方形，长{{length}}厘米，宽{{width}}厘米，这个长方形的面积是多少？',
    '长方形的长为{{length}}cm，宽为{{width}}cm，求它的面积',
    '已知一个长方形的长是{{length}}厘米，宽是{{width}}厘米，计算其面积',
    '{{length}}厘米长、{{width}}厘米宽的长方形面积是多少平方厘米？'
  ],
  type: "calculation",
  knowledge_code: "math-grade5-geometry-area-rectangle",
  difficulty: DIFFICULTY_LEVEL.MEDIUM,
  variables: {
    length: { type: "integer", min: 1, max: 100 },
    width: { type: "integer", min: 1, max: 100 }
  },
  answer: (length, width) => {
    return length * width;
  }
};

if (!validateTemplate(template)) {
  throw new Error(`Template validation failed for ${template.template_id}`);
}

export default template;