// templates/math/grade6/applied-problems/distance-speed-time.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE6-APPLIED-DISTANCE-001",
  template_name: "距离速度时间问题",
  description: "六年级行程问题，应用距离=速度×时间的公式",
  grade: GRADE_LEVEL.GRADE6,
  template: '一辆汽车以每小时{{speed}}公里的速度行驶，行驶了{{time}}小时，这辆汽车一共行驶了多少公里？',
  type: "calculation",
  knowledge_code: "math-grade6-applied-distance-speed-time",
  difficulty: DIFFICULTY_LEVEL.HARD,
  variables: {
    speed: { type: "integer", min: 10, max: 120 },
    time: { type: "number", min: 0.5, max: 10 }
  },
  answer: (speed, time) => {
    return speed * time;
  }
};

if (!validateTemplate(template)) {
  throw new Error(`Template validation failed for ${template.template_id}`);
}

export default template;