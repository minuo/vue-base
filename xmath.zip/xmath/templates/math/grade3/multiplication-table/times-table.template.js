// templates/math/grade3/multiplication-table/times-table.template.js
import { DIFFICULTY_LEVEL } from '../../common/constants.js';
import { GRADE_LEVEL } from '../../common/grade-levels.js';
import { validateTemplate } from '../../common/utils.js';

const template = {
  template_id: "MATH-GRADE3-MULTIPLICATION-TABLE-001",
  template_name: "乘法表练习",
  description: "三年级乘法表基础练习，帮助学生熟练掌握乘法口诀",
  grade: GRADE_LEVEL.GRADE3,
  template: '{{num1}} × {{num2}} = ?',
  type: "calculation",
  knowledge_code: "math-grade3-multiplication-table-basic",
  difficulty: DIFFICULTY_LEVEL.MEDIUM,
  variables: {
    num1: { type: "integer", min: 1, max: 9 },
    num2: { type: "integer", min: 1, max: 9 }
  },
  answer: (num1, num2) => {
    return num1 * num2;
  }
};

if (!validateTemplate(template)) {
  throw new Error(`Template validation failed for ${template.template_id}`);
}

export default template;