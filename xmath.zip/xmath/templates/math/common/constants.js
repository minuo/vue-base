// 模板常量定义
// 难度级别枚举
export const DIFFICULTY_LEVEL = {
  EASY: "easy",
  MEDIUM: "medium",
  HARD: "hard"
};

// 题目类型枚举
export const QUESTION_TYPE = {
  CALCULATION: "calculation",
  CHOICE: "choice",
  FILL_BLANK: "fill_blank",
  APPLIED: "applied"
};