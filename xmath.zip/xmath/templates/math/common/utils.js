// 模板验证工具函数
export const validateTemplate = (template) => {
  // 验证必填字段
  const requiredFields = [
    "template_id", "template_name", "grade", "knowledge_code",
    "difficulty", "variables", "answer"
  ];
  
  // 检查是否所有必填字段都存在
  for (const field of requiredFields) {
    if (!template.hasOwnProperty(field)) {
      console.error(`Validation failed: Missing required field '${field}'`);
      return false;
    }
  }
  
  // 验证模板字符串 - 支持单个 template 或 templates 数组
  if (!template.template && !template.templates) {
    console.error("Validation failed: Either 'template' or 'templates' field must be provided");
    return false;
  }
  
  // 如果是 templates 数组，验证每个元素都是字符串
  if (template.templates) {
    if (!Array.isArray(template.templates)) {
      console.error("Validation failed: 'templates' must be an array");
      return false;
    }
    
    for (const temp of template.templates) {
      if (typeof temp !== "string") {
        console.error("Validation failed: Each template in 'templates' array must be a string");
        return false;
      }
    }
  }
  
  // 验证 variables 字段
  if (typeof template.variables !== "object" || template.variables === null) {
    console.error("Validation failed: 'variables' must be an object");
    return false;
  }
  
  // 验证 answer 字段是函数
  if (typeof template.answer !== "function") {
    console.error("Validation failed: 'answer' must be a function");
    return false;
  }
  
  console.log(`Template validation passed for ${template.template_id}`);
  return true;
};

// 从模板数组中随机选择一个模板
export const selectRandomTemplate = (templates) => {
  if (Array.isArray(templates) && templates.length > 0) {
    const randomIndex = Math.floor(Math.random() * templates.length);
    return templates[randomIndex];
  }
  return null;
};

// 渲染模板字符串
export const renderTemplate = (templateStr, variables) => {
  let result = templateStr;
  for (const [key, value] of Object.entries(variables)) {
    const placeholder = `{{${key}}}`;
    result = result.replace(placeholder, value);
  }
  return result;
};