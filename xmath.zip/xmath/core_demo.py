#!/usr/bin/env python3
"""
智能小学数学题库系统 - 核心功能示例
演示知识点管理、试题生成和学情分析的基本实现
"""

import json
import random
import datetime
from typing import List, Dict, Optional

# 模拟数据库
knowledge_points_db = []
questions_db = []
student_profiles_db = []


class KnowledgePoint:
    """知识点类"""
    def __init__(self, knowledge_code: str, grade: int, volume: str, module: str, knowledge_point: str, difficulty_level: str):
        self.knowledge_code = knowledge_code
        self.grade = grade
        self.volume = volume
        self.module = module
        self.knowledge_point = knowledge_point
        self.difficulty_level = difficulty_level
        self.error_points = []
        self.prerequisite_knowledge = []
        self.cognitive_load = {'intrinsic': '中', 'extraneous': '低', 'germane': '中'}
    
    def to_dict(self):
        """转换为字典格式"""
        return {
            "knowledge_code": self.knowledge_code,
            "grade": self.grade,
            "volume": self.volume,
            "module": self.module,
            "knowledge_point": self.knowledge_point,
            "difficulty_level": self.difficulty_level,
            "error_points": self.error_points,
            "prerequisite_knowledge": self.prerequisite_knowledge,
            "cognitive_load": self.cognitive_load
        }


class Question:
    """试题类"""
    def __init__(self, question_id: str, knowledge_code: str, difficulty: str, question_type: str, question_content: str, answer: str, analysis: str):
        self.question_id = question_id
        self.knowledge_code = knowledge_code
        self.difficulty = difficulty
        self.question_type = question_type
        self.question_content = question_content
        self.answer = answer
        self.analysis = analysis
        self.error_point_code = None
        self.examine_type = "基础"
        self.created_at = datetime.datetime.now()
    
    def to_dict(self):
        """转换为字典格式"""
        return {
            "question_id": self.question_id,
            "knowledge_code": self.knowledge_code,
            "difficulty": self.difficulty,
            "question_type": self.question_type,
            "question_content": self.question_content,
            "answer": self.answer,
            "analysis": self.analysis,
            "error_point_code": self.error_point_code,
            "examine_type": self.examine_type,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class StudentProfile:
    """学生档案类"""
    def __init__(self, student_id: str, grade: int):
        self.student_id = student_id
        self.grade = grade
        self.knowledge_mastery = {}  # {知识点编码: 掌握度(0-1)}
        self.error_patterns = []      # 错误模式
        self.learning_style = "视觉型"
        self.answer_history = []      # 答题历史
    
    def to_dict(self):
        """转换为字典格式"""
        return {
            "student_id": self.student_id,
            "grade": self.grade,
            "knowledge_mastery": self.knowledge_mastery,
            "error_patterns": self.error_patterns,
            "learning_style": self.learning_style,
            "answer_history": self.answer_history
        }


def init_sample_data():
    """初始化示例数据"""
    print("初始化示例数据...")
    
    # 添加示例知识点
    sample_knowledge = KnowledgePoint(
        knowledge_code="X6-C1-K1-Z01",
        grade=6,
        volume="上册",
        module="数与代数",
        knowledge_point="分数乘法",
        difficulty_level="进阶"
    )
    sample_knowledge.error_points = [
        {"error_point_code": "X6-C1-K1-Z01-Y01", "error_content": "忘记约分"},
        {"error_point_code": "X6-C1-K1-Z01-Y02", "error_content": "分数乘法当加法做"}
    ]
    sample_knowledge.prerequisite_knowledge = ["X5-C2-K1-Z01"]
    knowledge_points_db.append(sample_knowledge)
    
    print(f"已添加 {len(knowledge_points_db)} 个知识点")
    print("初始化完成！")


def generate_questions(grade: int, volume: str, knowledge_code: str, difficulty: str, question_type: str, count: int) -> List[Dict]:
    """生成指定条件的试题"""
    print(f"开始生成试题 - 年级: {grade}, 知识点: {knowledge_code}, 难度: {difficulty}, 类型: {question_type}, 数量: {count}")
    
    # 模拟模板
    templates = {
        "应用题": "{num1} 个苹果，分给小红它的 {frac_n}/{frac_d}，小红能拿到多少个苹果？",
        "计算题": "计算: {num2} × {frac_n}/{frac_d} = ?"
    }
    
    generated_questions = []
    
    for i in range(count):
        question_id = f"QS-{datetime.datetime.now().strftime('%Y%m%d')}-{str(i+1).zfill(3)}"
        
        # 生成随机数值
        num_range = {"易": (1, 20), "中": (1, 100), "难": (1, 500)}[difficulty]
        num1 = random.randint(*num_range)
        num2 = random.randint(*num_range)
        frac_n = random.randint(1, 10)
        frac_d = random.randint(2, 10)
        
        # 选择模板并填充变量
        template = templates.get(question_type, templates["应用题"])
        question_content = template.replace("{num1}", str(num1))
        question_content = question_content.replace("{num2}", str(num2))
        question_content = question_content.replace("{frac_n}", str(frac_n))
        question_content = question_content.replace("{frac_d}", str(frac_d))
        
        # 计算答案
        answer = str(int(num1 * frac_n / frac_d))
        
        # 创建试题对象
        question = Question(
            question_id=question_id,
            knowledge_code=knowledge_code,
            difficulty=difficulty,
            question_type=question_type,
            question_content=question_content,
            answer=answer,
            analysis=f"解题核心：乘法运算，答案为 {answer}"
        )
        
        # 添加到生成列表
        generated_questions.append(question.to_dict())
        questions_db.append(question)
    
    print(f"成功生成 {count} 道试题")
    return generated_questions


def generate_adaptive_questions(student_id: str, count: int = 10) -> List[Dict]:
    """根据学生学情生成个性化试题"""
    print(f"为学生 {student_id} 生成个性化试题...")
    
    # 查找学生档案
    student_profile = None
    for profile in student_profiles_db:
        if profile.student_id == student_id:
            student_profile = profile
            break
    
    if not student_profile:
        print(f"学生 {student_id} 不存在，创建新档案")
        student_profile = StudentProfile(student_id, grade=6)
        student_profiles_db.append(student_profile)
    
    # 分析学生薄弱点
    weak_knowledge = find_weak_knowledge_points(student_profile)
    
    # 生成针对性试题
    adaptive_questions = []
    for knowledge in weak_knowledge:
        questions = generate_questions(
            grade=student_profile.grade,
            volume="上册",
            knowledge_code=knowledge["code"],
            difficulty=knowledge["suggested_difficulty"],
            question_type="应用题",
            count=int(count / len(weak_knowledge))
        )
        adaptive_questions.extend(questions)
    
    print(f"为学生 {student_id} 生成了 {len(adaptive_questions)} 道个性化试题")
    return adaptive_questions


def find_weak_knowledge_points(student: StudentProfile) -> List[Dict]:
    """查找学生薄弱知识点"""
    print("分析学生薄弱知识点...")
    
    weak_points = []
    
    # 模拟薄弱知识点分析
    for knowledge in knowledge_points_db:
        mastery = student.knowledge_mastery.get(knowledge.knowledge_code, 0.5)
        if mastery < 0.7:  # 低于70%掌握度
            weak_points.append({
                "code": knowledge.knowledge_code,
                "name": knowledge.knowledge_point,
                "mastery": mastery,
                "suggested_difficulty": "中" if mastery >= 0.5 else "易"
            })
    
    if not weak_points:
        # 如果没有薄弱点，返回当前年级的重点知识点
        weak_points.append({
            "code": knowledge_points_db[0].knowledge_code,
            "name": knowledge_points_db[0].knowledge_point,
            "mastery": 0.5,
            "suggested_difficulty": "中"
        })
    
    return weak_points


def update_student_mastery(student_id: str, knowledge_code: str, is_correct: bool, time_spent: int = 60):
    """更新学生知识掌握度"""
    print(f"更新学生 {student_id} 对知识点 {knowledge_code} 的掌握度...")
    
    for student in student_profiles_db:
        if student.student_id == student_id:
            current_mastery = student.knowledge_mastery.get(knowledge_code, 0.5)
            
            # 简单的掌握度更新算法
            adjustment = 0.1 if is_correct else -0.15
            new_mastery = max(0, min(1, current_mastery + adjustment))
            student.knowledge_mastery[knowledge_code] = new_mastery
            
            print(f"掌握度更新: {current_mastery:.2f} -> {new_mastery:.2f}")
            break


if __name__ == "__main__":
    print("智能小学数学题库系统")
    print("=" * 50)
    
    # 初始化数据
    init_sample_data()
    
    print("\n1. 生成基础试题示例:")
    basic_questions = generate_questions(grade=6, volume="上册", knowledge_code="X6-C1-K1-Z01", difficulty="中", question_type="应用题", count=3)
    for q in basic_questions:
        print(f"   - {q['question_content']}")
    
    print("\n2. 生成个性化试题示例:")
    adaptive_questions = generate_adaptive_questions(student_id="S-001", count=5)
    for q in adaptive_questions:
        print(f"   - {q['question_content']}")
    
    print("\n3. 更新学生掌握度示例:")
    update_student_mastery(student_id="S-001", knowledge_code="X6-C1-K1-Z01", is_correct=True)
    
    print("\n\n程序运行完成！")
