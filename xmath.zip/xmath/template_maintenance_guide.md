# 小学数学模板系统维护指南

本指南为模板系统的长期维护提供全面的策略和最佳实践，确保系统保持稳定性、可扩展性和教学有效性。

## 一、维护工具自动化

### 1.1 模板管理工具 (template-manager.js)
为了减少手动维护工作，系统提供了专门的自动化管理工具，您不再需要每次手动修改代码文件。

**主要功能：**
- 📝 交互式创建新模板
- 🔄 批量更新现有模板
- ✅ 一键验证所有模板
- 📊 模板质量检查

**使用方式：**
```bash
# 显示帮助
node template-manager.js help

# 创建新模板
node template-manager.js create

# 批量更新模板
node template-manager.js update

# 验证所有模板
node template-manager.js validate
```

**工具优势：**
- 遵循标准化模板结构，避免人为错误
- 交互式向导，简化复杂配置
- 批量处理功能，提高工作效率
- 实时验证，确保模板质量

### 1.2 其他辅助工具
- `demo_multiple_templates.js` - 演示多种模板变种的使用
- `core_demo.py` - 核心功能演示
- 自定义脚本可放在 `scripts/` 目录

## 一、系统架构与文件结构维护

### 1.1 目录结构规范
始终保持清晰的目录层级：
```
templates/
└── math/
    ├── common/           # 公共常量、工具、配置
    ├── grade1/          # 按年级分类
    ├── grade2/
    └── grade6/
        ├── addition/   # 按知识点分类
        ├── geometry/
        └── applied-problems/
            └── [feature].[template-type].template.js
```

### 1.2 文件命名标准
- 统一使用 kebab-case 命名
- 文件格式：`[功能].[类型].template.js`
- 示例：`area-calculation.rectangle.template.js`
- 功能部分：具体功能描述
- 类型部分：模板业务类型
- 必须包含 `.template.js` 后缀

## 二、模板质量保证体系

### 2.1 模板验证机制
使用 `validateTemplate()` 工具函数确保模板符合规范：
- 必填字段检查：`template_id`, `template_name`, `grade`, `type`, `variables`, `answer`, `templates`
- 字段类型验证
- 变量约束合规性检查
- 模板语法验证

### 2.2 单元测试策略
每个新模板必须包含单元测试：
- 测试模板元数据完整性
- 测试 `answer()` 函数正确性
- 测试多个模板表述功能
- 测试变量取值范围
- 测试模板渲染结果

### 2.3 集成测试流程
- 新增/修改模板时运行所有相关测试
- 测试跨模板兼容性
- 测试模板选择和渲染功能
- 性能测试，特别是变量替换部分

## 三、模板内容管理

### 3.1 内容审核流程
建立严格的内容审核机制：
- 教学专家审核题目表述
- 数学正确性验证
- 适合年级水平评估
- 教育性和趣味性平衡

### 3.2 模板更新策略
- **Bug 修复**：立即修复错误，确保数据一致性
- **功能增强**：新增功能需经过评审
- **版本管理**：重要修改需标注版本号
- **向后兼容**：避免破坏现有功能

### 3.3 模板归档与清理
- 过时模板标记为 `deprecated`
- 保留 6 个月后安全移除
- 记录删除原因和时间
- 提供归档备份

## 四、性能监控与优化

### 4.1 监控关键指标
- 模板加载时间
- 变量渲染性能
- 内存占用
- 错误日志分析

### 4.2 性能优化建议
- 使用 ES6 模块，减少导入开销
- 优化模板渲染算法
- 缓存常用模板组合
- 合理设置变量范围

## 五、安全管理

### 5.1 安全验证
- 所有模板必须通过安全规则检查
- 使用 `npx eslint templates/ --config template-security-rules.json`
- 禁止潜在危险的 JavaScript 代码
- 防止变量注入攻击

### 5.2 访问控制
- 限制模板目录的写入权限
- 对修改操作进行权限验证
- 记录所有模板变更日志

## 六、协作与沟通

### 6.1 开发流程
- 需求评审 → 实现 → 测试 → 审核 → 上线
- 使用 Git 分支管理变更
- 每次提交必须有清晰注释
- 建立 Code Review 机制

### 6.2 变更记录
保持详细的变更日志：
```markdown
# CHANGELOG.md

## [1.2.0] - 2024-01-15
### Added
- 新增三年级乘法表模板
- 添加多种题目表述支持

### Fixed
- 修复面积计算公式bug
```

## 七、工具与自动化

### 7.1 开发工具
- 使用 `template-manager.js` 自动化创建和更新模板
- 使用模板生成器自动创建基础模板
- 集成 CI/CD 工具自动测试和部署
- 建立代码 lint 规则，确保编码规范

### 7.2 自动化脚本
使用模板管理工具可以完全替代手动修改：

**创建新模板：**
```bash
node template-manager.js create
```

系统会通过交互式问答引导您完成所有配置，自动生成符合标准的模板文件。

**验证所有模板：**
```bash
node template-manager.js validate
```

**示例：创建新模板的完整流程**
```bash
node template-manager.js create
=== 创建新的数学模板 ===

请输入模板ID（如 MATH-GRADE3-ADDITION-001）: MATH-GRADE4-SUBTRACTION-001
请输入模板名称: 减法练习
请输入模板描述: 四年级减法基础练习
请输入年级（grade1 - grade6）: grade4
请输入知识点代码（如 math-grade3-addition-basic）: math-grade4-subtraction-basic
请输入题目类型（calculation, multiple_choice）: calculation
请输入难度级别（easy, medium, hard）: easy
请输入题目表述数量（3-5个）: 3
请输入第 1 个题目表述: {{num1}} - {{num2}} = ?
请输入第 2 个题目表述: 计算 {{num1}} 减 {{num2}} 等于多少
请输入第 3 个题目表述: {{num1}} 减去 {{num2}} 的结果是
请输入变量数量: 2
请输入第 1 个变量名: num1
请输入 num1 的类型（integer, number, string）: integer
请输入 num1 的最小值: 10
请输入 num1 的最大值: 100
请输入第 2 个变量名: num2
请输入 num2 的类型（integer, number, string）: integer
请输入 num2 的最小值: 1
请输入 num2 的最大值: 50
请输入答案函数代码（例如: (a, b) => a + b）:
> (num1, num2) => num1 - num2

✓ 创建目录: templates/math/grade4/subtraction
✓ 创建模板文件: templates/math/grade4/subtraction/subtraction.calculation.template.js

=== 模板创建完成 ===
📁 位置: templates/math/grade4/subtraction/subtraction.calculation.template.js
✅ 请运行 'node demo_multiple_templates.js' 测试新模板
```

## 八、常见问题与解决方案

### 8.1 模板渲染错误
- 检查变量名称是否一致
- 验证模板语法是否正确
- 确认变量取值范围合规

### 8.2 性能问题
- 优化模板结构
- 减少不必要的复杂计算
- 考虑模板缓存

### 8.3 兼容性问题
- 保持工具函数的向后兼容性
- 更新旧模板使用新的 API
- 提供迁移工具

### 9.1 是否需要每次都手动修改代码文件？
**不需要！** 系统提供完整的自动化工具来管理模板。

**推荐的工作流程：**
1. 使用 `node template-manager.js create` 交互式创建新模板
2. 使用 `node template-manager.js validate` 验证模板质量
3. 使用批量更新功能保持系统一致性
4. 仅在特殊情况下才手动修改（如复杂的自定义功能）

**自动化工具的价值：**
- 减少人为错误
- 提高工作效率
- 保持代码一致性
- 降低维护成本
- 提高系统可靠性

### 9.2 模板渲染错误
- 检查变量名称是否一致
- 使用验证工具自动检测问题
- 确认变量取值范围合规

### 8.2 性能问题
- 优化模板结构
- 减少不必要的复杂计算
- 考虑模板缓存

### 8.3 兼容性问题
- 保持工具函数的向后兼容性
- 更新旧模板使用新的 API
- 提供迁移工具

## 九、定期维护任务

### 9.1 每日任务
- 监控系统日志
- 处理用户反馈

### 9.2 每周任务
- 运行所有测试
- 清理临时文件
- 审查新模板

### 9.3 每月任务
- 检查模板完整性
- 更新依赖包
- 优化系统性能

### 9.4 季度任务
- 模板使用情况分析
- 需求调研
- 系统架构评估

通过严格遵循以上维护指南，您的小学数学模板系统将保持持续的高质量、可扩展性和稳定性，为学生和教师提供可靠的教学工具。