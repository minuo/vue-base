# 试题模板单独文件存储方案分析

## 一、当前模板结构特点分析

用户提供的模板结构具有以下重要特性：

```javascript
{
  template: '{{ceramic}}{{origin}}，某店有一套{{ceramic}}茶具...',
  type: "fill-in",
  operation: "*",
  constraints: { num1: { min: 5, max: 20 } },
  answer: (num1, num2, num3, num4) => {
    const teapotPrice = num1 * num2;
    const remainingMoney = num3 - teapotPrice;
    const costOfCups = num1 * num4;
    const isEnough = remainingMoney >= costOfCups ? "够" : "不够";
    return `${teapotPrice},${isEnough}`;
  },
  difficulty: DIFFICULTY_LEVEL.VERY_HARD,
  parameters: { ceramic: COMMON_PARAMS.CERAMIC_TYPE }
}
```

**核心特点**：
- 模板中包含 JavaScript 函数 (`answer`)
- 使用常量引用 (`DIFFICULTY_LEVEL`, `COMMON_PARAMS`)
- 结构复杂，包含多个元数据字段
- 具有动态计算能力

## 二、单独文件存储的可行性分析

### 2.1 完全可行的场景

#### 1. 开发阶段或小型项目
- **优点**：修改快速、调试方便、不需要额外数据库依赖
- **适用**：团队规模小、模板数量少、不需要多用户协作

#### 2. 模板作为代码资产管理
- **优点**：版本控制（Git）、代码审查、分支管理
- **适合**：需要严格质量控制的教育内容

#### 3. 静态或半静态模板
- **优点**：加载速度快、部署简单
- **适用**：变更频率低的标准化模板

### 2.2 潜在挑战

#### 1. 代码安全风险
- **问题**：`eval()` 或 `new Function()` 执行模板中的代码可能导致安全漏洞
- **案例**：恶意模板可能包含破坏性代码

#### 2. 动态加载和依赖管理
- **问题**：如何管理模板中的常量引用（`DIFFICULTY_LEVEL`, `COMMON_PARAMS`）
- **依赖关系**：模板需要访问外部定义的常量和函数

#### 3. 查询和搜索限制
- **问题**：文件系统没有数据库的查询能力
- **痛点**：按知识点、难度、题型筛选模板困难

#### 4. 维护复杂度
- **问题**：模板数量增多时文件管理变得复杂
- **场景**：数百个模板时查找和更新耗时

## 三、最佳实践建议

### 3.1 结构化文件存储方案

**方案**：将模板组织为模块化的 JavaScript 文件

```javascript
// templates/math/ceramic_tea_set.js
import { DIFFICULTY_LEVEL } from '../constants/difficulty.js';
import { COMMON_PARAMS } from '../constants/common_params.js';

export default {
  template_id: "MATH-TAKEAWAY-001",
  template: '{{ceramic}}{{origin}}，某店有一套{{ceramic}}茶具...',
  type: "fill-in",
  operation: "*",
  constraints: { num1: { min: 5, max: 20 } },
  answer: (num1, num2, num3, num4) => {
    const teapotPrice = num1 * num2;
    const remainingMoney = num3 - teapotPrice;
    const costOfCups = num1 * num4;
    const isEnough = remainingMoney >= costOfCups ? "够" : "不够";
    return `${teapotPrice},${isEnough}`;
  },
  difficulty: DIFFICULTY_LEVEL.VERY_HARD,
  parameters: { ceramic: COMMON_PARAMS.CERAMIC_TYPE },
  knowledge_code: "math-arithmetic-multiplication-applied"
}
```

### 3.2 模板管理系统设计

```python
import os
import importlib.util
from typing import List, Dict, Any

class FileTemplateManager:
    """文件系统模板管理器"""
    
    def __init__(self, templates_directory: str):
        self.templates_directory = templates_directory
        self.templates = []
        self._load_templates()
    
    def _load_templates(self):
        """递归加载所有模板文件"""
        for root, dirs, files in os.walk(self.templates_directory):
            for file in files:
                if file.endswith('.js') or file.endswith('.py'):
                    template = self._load_template_from_file(os.path.join(root, file))
                    if template:
                        self.templates.append(template)
    
    def _load_template_from_file(self, file_path: str) -> Dict[str, Any]:
        """从单个文件加载模板"""
        # 这里简化实现，实际需要根据语言处理
        # 对于Python可以使用importlib
        # 对于JavaScript可能需要Node.js环境或转换
        pass
    
    def get_templates_by_difficulty(self, difficulty: str) -> List[Dict[str, Any]]:
        """按难度筛选模板"""
        return [t for t in self.templates if t.get('difficulty') == difficulty]
    
    def search_templates(self, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """多条件搜索模板"""
        results = self.templates
        for key, value in filters.items():
            results = [t for t in results if t.get(key) == value]
        return results
```

### 3.3 推荐的混合方案

```
开发阶段 + 小型项目:     文件存储（快速迭代、版本控制）
生产环境 + 大型系统:     数据库存储（性能、查询、协作）
模板仓库管理:            Git + 文件系统（版本历史、审查）
```

## 四、具体实施建议

### 4.1 短期方案（快速启动）
- **方式**：模板存储在 `.js`/`.json` 文件中
- **组织**：按知识点/题型分类目录
- **工具**：使用 ES6 模块系统或 CommonJS

### 4.2 中期方案（系统扩展）
- **方式**：模板存储在 MongoDB（支持动态结构）
- **转换工具**：开发脚本批量导入文件到数据库
- **缓存**：Redis 缓存热门模板

### 4.3 长期方案（企业级）
- **方式**：混合存储（文件 + 数据库 + 缓存）
- **协作平台**：教师在线编辑界面
- **审核机制**：模板发布前的质量审查

## 五、结论

**直接存储在单独文件中是完全可行的**，尤其适合：
1. 开发阶段或小型项目
2. 需要严格版本控制的场景
3. 模板变更不频繁的项目

但需要注意：
- **安全问题**：避免使用 `eval()` 执行不可信代码
- **依赖管理**：统一管理模板中的常量和外部引用
- **可扩展性**：提前规划向数据库存储的迁移路径

对于大型、高并发、需要多用户协作的系统，推荐最终迁移到数据库存储方案以获得更好的查询、性能和协作能力。