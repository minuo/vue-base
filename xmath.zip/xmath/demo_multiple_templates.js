#!/usr/bin/env node

// 演示文件：展示如何使用支持多种题目变种的长方形面积计算模板
import areaTemplate from './templates/math/grade5/geometry/area-calculation.rectangle.template.js';
import { selectRandomTemplate, renderTemplate } from './templates/math/common/utils.js';

console.log('=== 长方形面积计算模板演示 ===\n');

// 显示模板基本信息
console.log('模板ID:', areaTemplate.template_id);
console.log('模板名称:', areaTemplate.template_name);
console.log('适用年级:', areaTemplate.grade);
console.log('难度:', areaTemplate.difficulty);
console.log('知识点:', areaTemplate.knowledge_code);
console.log('可用题目变种数量:', areaTemplate.templates.length);
console.log('\n--- 所有题目变种 ---');
areaTemplate.templates.forEach((temp, index) => {
  console.log(`${index + 1}: ${temp}`);
});

// 生成10道不同表述的题目示例
console.log('\n--- 生成的题目示例 ---');
for (let i = 1; i <= 10; i++) {
  // 随机生成变量值
  const length = Math.floor(Math.random() * 100) + 1; // 1-100
  const width = Math.floor(Math.random() * 100) + 1;  // 1-100
  
  // 选择一个随机模板
  const selectedTemplate = selectRandomTemplate(areaTemplate.templates);
  
  // 渲染模板
  const question = renderTemplate(selectedTemplate, { length, width });
  
  // 计算答案
  const answer = areaTemplate.answer(length, width);
  
  console.log(`${i}. ${question}`);
  console.log(`   答案: ${answer} 平方厘米`);
}

console.log('\n=== 演示完成 ===');
console.log('\n说明：');
console.log('1. 系统现在支持单个模板文件中定义多个题目表述');
console.log('2. 通过 selectRandomTemplate() 从多个表述中随机选择');
console.log('3. 使用 renderTemplate() 渲染具体题目');
console.log('4. 同一个知识点的所有题目共享变量定义和答案计算逻辑');