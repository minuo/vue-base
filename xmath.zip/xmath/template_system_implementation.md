# 模板生成功能实现方案

## 一、模板数据结构与设计

### 1.1 模板元数据结构

```json
{
  "template_id": "TMP-FRACTION-MUL-001",
  "template_name": "分数乘法应用题模板",
  "knowledge_code": "X6-C1-K1-Z01",
  "question_type": "应用题",
  "difficulty": "中",
  "template_content": {
    "question": "{人物}有{数量1}个{物品}，分给{人物2}它的{分数分子}/{分数分母}，{人物2}能拿到多少个{物品}？",
    "answer": "{答案}",
    "analysis": "解题核心：{数量1}×{分数分子}/{分数分母}={答案}；注意分数乘法的计算规则"
  },
  "variables": [
    {
      "name": "人物",
      "type": "string",
      "source": "name_list",
      "options": ["小明", "小红", "小刚", "小丽"]
    },
    {
      "name": "人物2",
      "type": "string",
      "source": "name_list",
      "options": ["小红", "小刚", "小丽", "小明"],
      "exclude": ["人物"]
    },
    {
      "name": "物品",
      "type": "string",
      "source": "common_items",
      "options": ["苹果", "铅笔", "糖果", "书"]
    },
    {
      "name": "数量1",
      "type": "integer",
      "min": 10,
      "max": 100,
      "step": 5
    },
    {
      "name": "分数分子",
      "type": "integer",
      "min": 1,
      "max": 10
    },
    {
      "name": "分数分母",
      "type": "integer",
      "min": 2,
      "max": 10,
      "constraint": "分数分母 > 分数分子"
    }
  ],
  "constraints": [
    "数量1必须是分数分母的倍数",
    "人物不能与人物2相同"
  ],
  "tags": ["分数乘法", "应用题", "小学六年级"],
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z",
  "status": "active"
}
```

### 1.2 关键字段说明

| 字段名             | 类型   | 说明                                                                 | 是否必填 |
|--------------------|--------|----------------------------------------------------------------------|----------|
| `template_id`      | 字符串 | 模板唯一标识，格式：`TMP-<模块标识>-<用途标识>-<序号>`                | 是       |
| `template_name`    | 字符串 | 模板名称，清晰描述模板用途                                           | 是       |
| `knowledge_code`   | 字符串 | 关联的知识点编码                                                     | 是       |
| `question_type`    | 字符串 | 题目类型（选择题、填空题、应用题等）                                 | 是       |
| `difficulty`       | 字符串 | 难度级别（低、中、高）                                               | 是       |
| `template_content` | 对象   | 包含题目、答案、解析的模板内容                                       | 是       |
| `variables`        | 数组   | 模板中的动态变量列表                                                 | 是       |
| `constraints`      | 数组   | 变量间约束条件                                                       | 否       |
| `tags`             | 数组   | 模板标签，用于分类和搜索                                             | 否       |
| `status`           | 字符串 | 模板状态（active/inactive/draft）                                     | 是       |

---

## 二、模板变量类型与约束

### 2.1 支持的变量类型

```python
class VariableType(Enum):
    INTEGER = "integer"       # 整数
    FLOAT = "float"           # 浮点数
    STRING = "string"         # 字符串
    LIST = "list"             # 列表类型
    DATE = "date"             # 日期类型
```

### 2.2 变量约束规则

```python
class VariableConstraint:
    def __init__(self, variable_name, constraint_type, params):
        self.variable_name = variable_name
        self.constraint_type = constraint_type  # range, unique, dependency等
        self.params = params                    # 约束参数
    
    def validate(self, value, context=None):
        """验证变量值是否符合约束"""
        if self.constraint_type == "range":
            return self.params['min'] <= value <= self.params['max']
        elif self.constraint_type == "unique":
            return value not in context.get('used_values', [])
        return True
```

---

## 三、核心实现代码

### 3.1 模板管理模块

```python
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any

class TemplateManager:
    """模板管理类，负责模板的创建、修改、验证和查询"""
    
    def __init__(self, db):
        self.db = db
    
    def create_template(self, template_data: Dict[str, Any]) -> Dict[str, Any]:
        """创建新模板"""
        # 验证模板数据
        self.validate_template(template_data)
        
        # 生成唯一ID
        template_id = f"TMP-{template_data['knowledge_code'].split('-')[-1]}-{uuid.uuid4().hex[:3].upper()}"
        template_data['template_id'] = template_id
        
        # 添加时间戳
        current_time = datetime.utcnow().isoformat() + "Z"
        template_data['created_at'] = current_time
        template_data['updated_at'] = current_time
        
        # 保存到数据库
        self.db.templates.insert_one(template_data)
        
        return template_data
    
    def validate_template(self, template_data: Dict[str, Any]) -> None:
        """验证模板数据完整性和有效性"""
        required_fields = [
            'template_name', 'knowledge_code', 'question_type', 
            'difficulty', 'template_content', 'variables'
        ]
        
        for field in required_fields:
            if field not in template_data:
                raise ValueError(f"Missing required field: {field}")
        
        # 验证模板内容结构
        if not isinstance(template_data['template_content'], dict) or \
           'question' not in template_data['template_content']:
            raise ValueError("Invalid template_content structure")
        
        # 验证变量定义
        for var in template_data['variables']:
            if 'name' not in var or 'type' not in var:
                raise ValueError("Variable definition missing required fields")
    
    def generate_questions_from_template(
        self, 
        template_id: str, 
        count: int = 1
    ) -> List[Dict[str, Any]]:
        """从模板生成指定数量的题目"""
        template = self.db.templates.find_one({'template_id': template_id})
        if not template:
            raise ValueError(f"Template not found: {template_id}")
        
        questions = []
        for _ in range(count):
            # 生成变量值
            variable_values = self._generate_variable_values(template['variables'], template.get('constraints', []))
            
            # 渲染模板
            question = self._render_template(template, variable_values)
            questions.append(question)
        
        return questions
    
    def _generate_variable_values(
        self, 
        variables: List[Dict[str, Any]], 
        constraints: List[str]
    ) -> Dict[str, Any]:
        """生成符合约束的变量值"""
        import random
        variable_values = {}
        
        for var in variables:
            var_name = var['name']
            var_type = var['type']
            
            if var_type == 'integer':
                value = random.randint(var.get('min', 0), var.get('max', 100))
                if 'step' in var:
                    value = value - (value % var['step'])
            elif var_type == 'string':
                if 'options' in var:
                    value = random.choice(var['options'])
                    # 处理排除约束
                    if 'exclude' in var:
                        for exclude_var in var['exclude']:
                            if exclude_var in variable_values:
                                while value == variable_values[exclude_var]:
                                    value = random.choice(var['options'])
                else:
                    value = f"{var_name}_value"
            
            variable_values[var_name] = value
        
        # 处理计算型变量
        if '分数分子' in variable_values and '分数分母' in variable_values and '数量1' in variable_values:
            numerator = variable_values['分数分子']
            denominator = variable_values['分数分母']
            quantity = variable_values['数量1']
            variable_values['答案'] = quantity * numerator // denominator
        
        return variable_values
    
    def _render_template(
        self, 
        template: Dict[str, Any], 
        variable_values: Dict[str, Any]
    ) -> Dict[str, Any]:
        """使用变量值渲染模板生成题目"""
        rendered = {
            'template_id': template['template_id'],
            'knowledge_code': template['knowledge_code'],
            'question_type': template['question_type'],
            'difficulty': template['difficulty']
        }
        
        # 渲染题目、答案、解析
        for key, content in template['template_content'].items():
            rendered[key] = content
            for var_name, var_value in variable_values.items():
                rendered[key] = rendered[key].replace(f"{{{var_name}}}", str(var_value))
        
        return rendered
    
    def update_template(self, template_id: str, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """更新模板"""
        # 验证更新数据
        if 'template_id' in update_data:
            del update_data['template_id']
        
        update_data['updated_at'] = datetime.utcnow().isoformat() + "Z"
        
        self.db.templates.update_one(
            {'template_id': template_id}, 
            {'$set': update_data}
        )
        
        return self.db.templates.find_one({'template_id': template_id})
    
    def get_templates(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """查询模板"""
        return list(self.db.templates.find(filters or {}))
```

### 3.2 使用示例

```python
if __name__ == "__main__":
    from pymongo import MongoClient
    
    # 初始化数据库连接（示例）
    client = MongoClient("mongodb://localhost:27017/")
    db = client["math_question_bank"]
    
    # 创建模板管理器
    template_manager = TemplateManager(db)
    
    # 示例模板数据
    sample_template = {
        "template_name": "分数乘法应用题模板",
        "knowledge_code": "X6-C1-K1-Z01",
        "question_type": "应用题",
        "difficulty": "中",
        "template_content": {
            "question": "{人物}有{数量1}个{物品}，分给{人物2}它的{分数分子}/{分数分母}，{人物2}能拿到多少个{物品}？",
            "answer": "{答案}",
            "analysis": "解题核心：{数量1}×{分数分子}/{分数分母}={答案}；注意分数乘法的计算规则"
        },
        "variables": [
            {"name": "人物", "type": "string", "options": ["小明", "小红", "小刚", "小丽"]},
            {"name": "人物2", "type": "string", "options": ["小红", "小刚", "小丽", "小明"], "exclude": ["人物"]},
            {"name": "物品", "type": "string", "options": ["苹果", "铅笔", "糖果", "书"]},
            {"name": "数量1", "type": "integer", "min": 10, "max": 100, "step": 5},
            {"name": "分数分子", "type": "integer", "min": 1, "max": 10},
            {"name": "分数分母", "type": "integer", "min": 2, "max": 10}
        ],
        "constraints": ["数量1必须是分数分母的倍数"],
        "tags": ["分数乘法", "应用题", "小学六年级"],
        "status": "active"
    }
    
    try:
        # 创建模板
        print("Creating template...")
        created_template = template_manager.create_template(sample_template)
        print(f"Template created successfully: {created_template['template_id']}")
        
        # 生成5道题目
        print("\nGenerating questions...")
        questions = template_manager.generate_questions_from_template(created_template['template_id'], 5)
        for i, q in enumerate(questions):
            print(f"\nQuestion {i+1}:")
            print(f"{q['question']}")
            print(f"Answer: {q['answer']}")
            print(f"Analysis: {q['analysis']}")
    except Exception as e:
        print(f"Error: {str(e)}")
```

---

## 四、最佳实践与注意事项

### 4.1 模板设计原则
1. **清晰明确**：模板内容应简洁明了，避免歧义
2. **扩展性强**：变量设计应考虑未来扩展需求
3. **约束完整**：定义适当的变量约束，确保生成题目质量
4. **语义化**：使用有意义的变量名和模板标识

### 4.2 性能优化策略
- 预渲染模板以提高生成速度
- 缓存常用模板和变量组合
- 批量处理生成请求

### 4.3 质量控制
- 模板内容需要经过教育专家审核
- 生成题目需要进行质量检测
- 建立模板反馈和优化机制

---

## 五、扩展功能

### 5.1 智能模板推荐
```python
def recommend_templates(student_profile: Dict[str, Any]) -> List[str]:
    """根据学生画像推荐最合适的模板"""
    weak_points = student_profile['weak_points']
    learning_style = student_profile['learning_style']
    
    # 基于知识点薄弱项和学习风格推荐模板
    templates = db.templates.find({
        'knowledge_code': {'$in': weak_points},
        'difficulty': {'$lte': student_profile['max_difficulty']}
    })
    
    return [t['template_id'] for t in templates]
```

### 5.2 模板版本管理
```python
class TemplateVersioning:
    """模板版本控制功能"""
    
    def create_version(self, template_id: str, version_notes: str):
        """创建新的模板版本"""
        template = db.templates.find_one({'template_id': template_id})
        version = {
            'version_id': f"{template_id}-v{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'template_data': template,
            'version_notes': version_notes,
            'created_at': datetime.utcnow()
        }
        db.template_versions.insert_one(version)
```